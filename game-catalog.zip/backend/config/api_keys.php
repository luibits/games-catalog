<?php

return [
    'RAWG_API_KEY' => '2a89d7e5b00845f197bf9ad79d17b332',
    'YOUTUBE_API_KEY' => 'AIzaSyCyNoDJxs2iNUtQI_JAqmmiUjFLic_zX8I'
];