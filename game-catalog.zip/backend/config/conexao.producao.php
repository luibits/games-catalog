<?php

$host = "sql311.infinityfree.com";
$dbname = "if0_43500551_checkpoint";
$user = "if0_43500551";
$pass = "hN8qhDoE6IZr";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $pass
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $error) {
    die("Erro de conexão: " . htmlspecialchars($error->getMessage()));
}
