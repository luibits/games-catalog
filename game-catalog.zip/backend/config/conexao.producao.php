<?php

$host = "sql311.infinityfree.com";
$dbname = "if0_43500551_XXX";
$user = "if0_43500551";
$pass = "hN8qhDoE6IZr";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $pass
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $error) {
    error_log("Erro na conexão com o banco: " . $error->getMessage());
    die("Não foi possível conectar ao banco de dados.");
}
